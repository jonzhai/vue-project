// 'use strict'

// export default (req, res, next) => {
// 	if ((/manage/gi).test(req.url)) {
// 		res.sendFile(__dirname + '/public/manage/index.html')
// 	}else{
// 		res.sendFile(__dirname + '/public/elm/index.html')
// 	}
// }